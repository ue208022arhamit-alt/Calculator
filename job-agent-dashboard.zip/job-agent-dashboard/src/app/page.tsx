'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Briefcase, 
  Play, 
  Settings, 
  TrendingUp, 
  CheckCircle2, 
  Clock, 
  XCircle,
  Building2,
  MapPin,
  Calendar,
  ExternalLink
} from 'lucide-react'

// Mock data - in production, this would come from your backend
const mockApplications = [
  {
    id: 1,
    jobTitle: 'Senior Frontend Developer',
    company: 'TechCorp Inc.',
    location: 'Remote',
    appliedDate: '2026-02-07',
    status: 'applied',
    platform: 'Indeed',
    url: 'https://indeed.com/job/123'
  },
  {
    id: 2,
    jobTitle: 'Full Stack Engineer',
    company: 'StartupXYZ',
    location: 'New York, NY',
    appliedDate: '2026-02-06',
    status: 'interview',
    platform: 'Indeed',
    url: 'https://indeed.com/job/124'
  },
  {
    id: 3,
    jobTitle: 'React Developer',
    company: 'Digital Agency Co',
    location: 'San Francisco, CA',
    appliedDate: '2026-02-05',
    status: 'rejected',
    platform: 'Indeed',
    url: 'https://indeed.com/job/125'
  }
]

const stats = {
  totalApplications: 24,
  pending: 18,
  interviews: 4,
  rejected: 2
}

export default function Dashboard() {
  const [applications, setApplications] = useState(mockApplications)
  const [isRunning, setIsRunning] = useState(false)

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'applied':
        return 'bg-blue-500'
      case 'interview':
        return 'bg-green-500'
      case 'rejected':
        return 'bg-red-500'
      default:
        return 'bg-gray-500'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'applied':
        return <Clock className="h-4 w-4" />
      case 'interview':
        return <CheckCircle2 className="h-4 w-4" />
      case 'rejected':
        return <XCircle className="h-4 w-4" />
      default:
        return <Clock className="h-4 w-4" />
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <div className="container mx-auto p-6 space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-4xl font-bold tracking-tight flex items-center gap-3">
              <Briefcase className="h-10 w-10 text-primary" />
              Job Application Agent
            </h1>
            <p className="text-muted-foreground mt-2">
              Automate your job search and track applications in one place
            </p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" size="lg">
              <Settings className="h-4 w-4 mr-2" />
              Configure
            </Button>
            <Button 
              size="lg" 
              onClick={() => setIsRunning(!isRunning)}
              className="min-w-[140px]"
            >
              <Play className="h-4 w-4 mr-2" />
              {isRunning ? 'Stop Agent' : 'Start Agent'}
            </Button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Applications
              </CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalApplications}</div>
              <p className="text-xs text-muted-foreground">
                +12% from last week
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Pending
              </CardTitle>
              <Clock className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.pending}</div>
              <p className="text-xs text-muted-foreground">
                Awaiting response
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Interviews
              </CardTitle>
              <CheckCircle2 className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.interviews}</div>
              <p className="text-xs text-muted-foreground">
                16.7% success rate
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Rejected
              </CardTitle>
              <XCircle className="h-4 w-4 text-red-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.rejected}</div>
              <p className="text-xs text-muted-foreground">
                8.3% of total
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Applications List */}
        <Tabs defaultValue="all" className="space-y-4">
          <TabsList>
            <TabsTrigger value="all">All Applications</TabsTrigger>
            <TabsTrigger value="pending">Pending</TabsTrigger>
            <TabsTrigger value="interview">Interviews</TabsTrigger>
            <TabsTrigger value="rejected">Rejected</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Recent Applications</CardTitle>
                <CardDescription>
                  Track all your job applications in one place
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {applications.map((app) => (
                    <div 
                      key={app.id}
                      className="flex flex-col md:flex-row md:items-center justify-between p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                    >
                      <div className="space-y-2 flex-1">
                        <div className="flex items-start gap-3">
                          <div className="flex-1">
                            <h3 className="font-semibold text-lg">{app.jobTitle}</h3>
                            <div className="flex flex-wrap gap-3 mt-2 text-sm text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <Building2 className="h-4 w-4" />
                                {app.company}
                              </span>
                              <span className="flex items-center gap-1">
                                <MapPin className="h-4 w-4" />
                                {app.location}
                              </span>
                              <span className="flex items-center gap-1">
                                <Calendar className="h-4 w-4" />
                                {new Date(app.appliedDate).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-3 mt-4 md:mt-0">
                        <Badge className={getStatusColor(app.status)}>
                          <span className="flex items-center gap-1">
                            {getStatusIcon(app.status)}
                            {app.status.charAt(0).toUpperCase() + app.status.slice(1)}
                          </span>
                        </Badge>
                        <Button variant="outline" size="sm" asChild>
                          <a href={app.url} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-4 w-4 mr-1" />
                            View Job
                          </a>
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pending">
            <Card>
              <CardHeader>
                <CardTitle>Pending Applications</CardTitle>
                <CardDescription>Applications waiting for response</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  {applications.filter(app => app.status === 'applied').length} pending applications
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="interview">
            <Card>
              <CardHeader>
                <CardTitle>Interview Stage</CardTitle>
                <CardDescription>Applications that progressed to interviews</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  {applications.filter(app => app.status === 'interview').length} interviews scheduled
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="rejected">
            <Card>
              <CardHeader>
                <CardTitle>Rejected Applications</CardTitle>
                <CardDescription>Applications that were not successful</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  {applications.filter(app => app.status === 'rejected').length} rejections
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
