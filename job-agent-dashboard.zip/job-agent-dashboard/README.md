# Job Application Agent Dashboard 🚀

A modern, beautiful Next.js dashboard to manage and automate your job applications using shadcn/ui components.

![Next.js](https://img.shields.io/badge/Next.js-14-black)
![TypeScript](https://img.shields.io/badge/TypeScript-5.3-blue)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-3.4-38bdf8)
![shadcn/ui](https://img.shields.io/badge/shadcn%2Fui-latest-000000)

## ✨ Features

- 📊 **Real-time Dashboard** - Track all your job applications in one place
- 🎨 **Beautiful UI** - Built with shadcn/ui and Tailwind CSS
- 📱 **Responsive Design** - Works perfectly on desktop, tablet, and mobile
- 🔄 **Live Status Tracking** - Monitor pending, interview, and rejected applications
- 📈 **Analytics** - View success rates and application trends
- 🎯 **Platform Integration** - Supports Indeed (more platforms coming soon)
- ⚡ **Fast & Modern** - Built with Next.js 14 and React Server Components

## 🖼️ Screenshots

### Dashboard Overview
View all your applications with status badges, company info, and quick actions.

### Application Stats
Track your success rate, pending applications, and interview progress.

### Filtered Views
Easily filter by application status (pending, interview, rejected).

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

1. **Extract the project files** to a folder

2. **Install dependencies**
   ```bash
   cd job-agent-dashboard
   npm install
   ```

3. **Run the development server**
   ```bash
   npm run dev
   ```

4. **Open your browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

That's it! Your dashboard is now running! 🎉

## 📁 Project Structure

```
job-agent-dashboard/
├── src/
│   ├── app/
│   │   ├── page.tsx          # Main dashboard page
│   │   ├── layout.tsx         # Root layout
│   │   └── globals.css        # Global styles + shadcn theme
│   ├── components/
│   │   └── ui/                # shadcn/ui components
│   │       ├── button.tsx
│   │       ├── card.tsx
│   │       ├── badge.tsx
│   │       ├── tabs.tsx
│   │       ├── input.tsx
│   │       └── label.tsx
│   └── lib/
│       └── utils.ts           # Utility functions
├── public/                    # Static files
├── package.json
├── tailwind.config.js         # Tailwind + shadcn config
├── tsconfig.json
└── next.config.js
```

## 🎨 Customization

### Adding More Components

To add more shadcn/ui components:

1. Visit [shadcn/ui](https://ui.shadcn.com/)
2. Copy the component code
3. Add to `src/components/ui/`

### Changing Colors

Edit the theme in `src/app/globals.css`:

```css
:root {
  --primary: 221.2 83.2% 53.3%;  /* Change primary color */
  --secondary: 210 40% 96.1%;    /* Change secondary color */
  /* ... more color variables */
}
```

### Connecting to Backend

Replace the mock data in `src/app/page.tsx`:

```typescript
// Current mock data
const mockApplications = [...]

// Replace with API call
const [applications, setApplications] = useState([])

useEffect(() => {
  fetch('/api/applications')
    .then(res => res.json())
    .then(data => setApplications(data))
}, [])
```

## 🔧 Available Scripts

```bash
# Development server
npm run dev

# Production build
npm run build

# Start production server
npm start

# Lint code
npm run lint
```

## 🎯 Next Steps

### Backend Integration

Create API routes in `src/app/api/`:

```typescript
// src/app/api/applications/route.ts
export async function GET() {
  // Fetch from database
  const applications = await db.applications.findMany()
  return Response.json(applications)
}

export async function POST(request: Request) {
  // Create new application
  const data = await request.json()
  const application = await db.applications.create({ data })
  return Response.json(application)
}
```

### Database Setup

Add Prisma or your preferred ORM:

```bash
npm install prisma @prisma/client
npx prisma init
```

### Connect Python Bot

Your Python bot can POST applications to the API:

```python
import requests

def save_application(job_data):
    response = requests.post(
        'http://localhost:3000/api/applications',
        json=job_data
    )
    return response.json()
```

### Add Authentication

Protect your dashboard with NextAuth.js:

```bash
npm install next-auth
```

## 🌟 Features to Add

Here are some ideas to extend the dashboard:

- [ ] **Email Notifications** - Get alerts for new interviews
- [ ] **Calendar Integration** - Sync interview dates
- [ ] **Cover Letter Generator** - AI-powered personalization
- [ ] **Resume Versions** - Manage multiple resume variants
- [ ] **Application Notes** - Add notes to each application
- [ ] **Export Data** - Download applications as CSV/PDF
- [ ] **Dark Mode Toggle** - Switch between light/dark themes
- [ ] **Multi-user Support** - Add user authentication
- [ ] **Analytics Charts** - Visualize application trends with recharts
- [ ] **Webhook Integration** - Connect to Slack, Discord, etc.

## 🎨 UI Components Included

This project uses the following shadcn/ui components:

- ✅ Button
- ✅ Card
- ✅ Badge
- ✅ Tabs
- ✅ Input
- ✅ Label

To add more:
- Dialog
- Dropdown Menu
- Select
- Switch
- Toast
- And 40+ more at [ui.shadcn.com](https://ui.shadcn.com)

## 📚 Tech Stack

- **Framework:** Next.js 14 (App Router)
- **Language:** TypeScript
- **Styling:** Tailwind CSS
- **Components:** shadcn/ui (Radix UI primitives)
- **Icons:** Lucide React
- **State Management:** React Hooks

## 🐛 Troubleshooting

### Port already in use
```bash
# Kill process on port 3000
lsof -ti:3000 | xargs kill -9

# Or use a different port
npm run dev -- -p 3001
```

### Module not found errors
```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install
```

### Styling not working
```bash
# Make sure Tailwind is configured
npm run dev
# Check browser console for errors
```

## 📖 Learn More

- [Next.js Documentation](https://nextjs.org/docs)
- [shadcn/ui Documentation](https://ui.shadcn.com)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)
- [TypeScript Documentation](https://www.typescriptlang.org/docs)

## 🤝 Contributing

Feel free to customize this dashboard for your needs! Some ways to contribute:

1. Add new features
2. Improve the UI/UX
3. Fix bugs
4. Add more platform integrations (LinkedIn, Glassdoor)
5. Create documentation

## 📝 License

This project is open source and available for personal use.

## 💡 Tips

1. **Start Simple** - Get the basic dashboard running first
2. **Add Features Gradually** - Don't try to build everything at once
3. **Use Real Data** - Connect to your Python bot via API
4. **Customize** - Make it your own with colors and layouts
5. **Deploy** - Use Vercel for free hosting

## 🚢 Deployment

Deploy to Vercel (recommended):

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel
```

Or deploy to:
- **Netlify**
- **Railway**
- **AWS Amplify**
- **DigitalOcean App Platform**

## 🎓 Tutorial Mode

If you're new to Next.js, follow this path:

1. ✅ Get the dashboard running (`npm run dev`)
2. 📝 Edit the mock data in `page.tsx`
3. 🎨 Change colors in `globals.css`
4. 🧩 Add a new shadcn component
5. 🔌 Create your first API route
6. 🗄️ Connect a database
7. 🚀 Deploy to production

---

**Happy job hunting! May your applications be many and your interviews be plentiful! 🎯**

Need help? Check out the [Next.js Discord](https://discord.gg/nextjs) or [shadcn/ui Discord](https://discord.gg/shadcn-ui)
