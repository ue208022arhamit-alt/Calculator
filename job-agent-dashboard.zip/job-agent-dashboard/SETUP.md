# 🚀 Quick Setup Guide

Get your Job Application Agent Dashboard running in 5 minutes!

## Step 1: Extract Files

Extract all files to a folder called `job-agent-dashboard`

## Step 2: Install Dependencies

Open terminal/command prompt in the `job-agent-dashboard` folder:

### Windows:
```bash
cd path\to\job-agent-dashboard
npm install
```

### Mac/Linux:
```bash
cd path/to/job-agent-dashboard
npm install
```

This will install:
- Next.js 14
- React 18
- TypeScript
- Tailwind CSS
- shadcn/ui components
- Lucide icons

## Step 3: Run Development Server

```bash
npm run dev
```

## Step 4: Open in Browser

Visit: **http://localhost:3000**

You should see your beautiful job application dashboard! 🎉

## What You'll See

- **Dashboard** with application statistics
- **Application cards** showing job details
- **Status badges** (Pending, Interview, Rejected)
- **Tabs** to filter applications
- **Start Agent** button (currently a demo)

## Next Steps

### 1. Customize the Mock Data

Edit `src/app/page.tsx` and update the `mockApplications` array with your own data:

```typescript
const mockApplications = [
  {
    id: 1,
    jobTitle: 'Your Job Title',
    company: 'Company Name',
    location: 'Location',
    appliedDate: '2026-02-08',
    status: 'applied', // or 'interview' or 'rejected'
    platform: 'Indeed',
    url: 'https://indeed.com/job/...'
  },
  // Add more applications...
]
```

### 2. Change Colors

Edit `src/app/globals.css` to customize the theme:

```css
:root {
  --primary: 221.2 83.2% 53.3%;  /* Blue by default */
}
```

### 3. Connect to Python Bot

Create an API route to receive data from your Python bot:

**Create:** `src/app/api/applications/route.ts`

```typescript
export async function POST(request: Request) {
  const application = await request.json()
  // Save to database or file
  return Response.json({ success: true })
}
```

**In your Python bot:**

```python
import requests

def save_application(job_data):
    requests.post(
        'http://localhost:3000/api/applications',
        json=job_data
    )
```

## Troubleshooting

### "Cannot find module..."
```bash
rm -rf node_modules package-lock.json
npm install
```

### "Port 3000 already in use"
```bash
npm run dev -- -p 3001
```
(Then visit http://localhost:3001)

### Styling looks wrong
Make sure you're in the correct folder and all files are present:
```bash
ls src/app/globals.css
ls tailwind.config.js
```

## File Structure

```
job-agent-dashboard/
├── src/
│   ├── app/
│   │   ├── page.tsx         ← Main dashboard (edit this!)
│   │   ├── layout.tsx
│   │   └── globals.css      ← Theme colors
│   ├── components/ui/       ← UI components (don't edit)
│   └── lib/utils.ts
├── package.json
├── tailwind.config.js
└── README.md               ← Full documentation
```

## Common Customizations

### Add a new stat card

In `src/app/page.tsx`, add to the stats grid:

```typescript
<Card>
  <CardHeader>
    <CardTitle>Your Stat</CardTitle>
  </CardHeader>
  <CardContent>
    <div className="text-2xl font-bold">42</div>
  </CardContent>
</Card>
```

### Change the primary color to purple

In `src/app/globals.css`:

```css
:root {
  --primary: 270 91% 65%;  /* Purple */
}
```

### Add more shadcn components

1. Visit https://ui.shadcn.com
2. Browse components
3. Copy code to `src/components/ui/`

## Production Build

When ready to deploy:

```bash
npm run build
npm start
```

Or deploy to Vercel (free):
```bash
npm i -g vercel
vercel
```

## Need Help?

1. Check `README.md` for detailed docs
2. Visit Next.js docs: https://nextjs.org/docs
3. Visit shadcn/ui docs: https://ui.shadcn.com

---

**You're all set! Happy coding! 🎉**
